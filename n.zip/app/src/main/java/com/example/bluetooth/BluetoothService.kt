package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.util.Log
import com.example.connection.ChatConnection
import com.example.model.BluetoothDeviceDomain
import com.example.model.BluetoothPacket
import com.example.model.ConnectionState
import com.example.model.PacketType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class BluetoothService(
    private val context: Context,
    val bluetoothManager: BluetoothManager
) : ChatConnection {
    private val TAG = "BluetoothService"
    private val APP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _receivedPackets = MutableSharedFlow<BluetoothPacket>(extraBufferCapacity = 128)
    override val receivedPackets: SharedFlow<BluetoothPacket> = _receivedPackets.asSharedFlow()

    private val _isPartnerTyping = MutableStateFlow(false)
    override val isPartnerTyping: StateFlow<Boolean> = _isPartnerTyping.asStateFlow()

    private var server: BluetoothServer? = null
    private var client: BluetoothClient? = null
    private var connection: BluetoothConnection? = null

    var lastConnectedDevice: BluetoothDeviceDomain? = null
        private set
    private var shouldAutoReconnect = false

    init {
        bluetoothManager.registerReceiver()
    }

    @SuppressLint("MissingPermission")
    override fun startHost() {
        stopAll()
        val adapter = bluetoothManager.adapter
        if (adapter == null || !adapter.isEnabled) {
            _connectionState.value = ConnectionState.Error("البلوتوث غير مفعل")
            return
        }

        _connectionState.value = ConnectionState.Listening
        server = BluetoothServer(adapter = adapter, uuid = APP_UUID)
        server?.startListening(
            onConnected = { socket ->
                handleSuccessfulConnection(socket)
            },
            onError = { errorMsg ->
                Log.e(TAG, "Host server error: $errorMsg")
                _connectionState.value = ConnectionState.Error(errorMsg)
            }
        )
    }

    override fun connectToDevice(addressOrIp: String, name: String?) {
        val domain = bluetoothManager.getDeviceByAddress(addressOrIp)?.let {
            BluetoothDeviceDomain(it.name ?: name ?: addressOrIp, it.address)
        } ?: BluetoothDeviceDomain(name ?: addressOrIp, addressOrIp)
        connectToDevice(domain)
    }

    @SuppressLint("MissingPermission")
    fun connectToDevice(deviceDomain: BluetoothDeviceDomain) {
        stopAll()
        val adapter = bluetoothManager.adapter
        if (adapter == null || !adapter.isEnabled) {
            _connectionState.value = ConnectionState.Error("البلوتوث غير مفعل")
            return
        }

        val device = bluetoothManager.getDeviceByAddress(deviceDomain.address)
        if (device == null) {
            _connectionState.value = ConnectionState.Error("الجهاز غير موجود")
            return
        }

        _connectionState.value = ConnectionState.Connecting(deviceDomain.name)
        lastConnectedDevice = deviceDomain
        shouldAutoReconnect = true

        client = BluetoothClient(adapter = adapter, uuid = APP_UUID)
        client?.connectToDevice(
            device = device,
            onConnected = { socket ->
                handleSuccessfulConnection(socket)
            },
            onError = { errorMsg ->
                Log.e(TAG, "Client connect error: $errorMsg")
                _connectionState.value = ConnectionState.Error("فشل الاتصال: $errorMsg")
                triggerAutoReconnect()
            }
        )
    }

    @SuppressLint("MissingPermission")
    private fun handleSuccessfulConnection(socket: BluetoothSocket) {
        server?.stop()
        server = null
        client = null

        val remoteName = try {
            socket.remoteDevice.name ?: socket.remoteDevice.address
        } catch (e: SecurityException) {
            socket.remoteDevice.address
        }

        val deviceDomain = BluetoothDeviceDomain(
            name = remoteName,
            address = socket.remoteDevice.address
        )
        lastConnectedDevice = deviceDomain
        shouldAutoReconnect = true

        _connectionState.value = ConnectionState.Connected(deviceDomain)

        connection = BluetoothConnection(
            socket = socket,
            onConnectionClosed = {
                Log.d(TAG, "Bluetooth Connection closed")
                _connectionState.value = ConnectionState.Disconnected
                _isPartnerTyping.value = false
                triggerAutoReconnect()
            }
        )

        serviceScope.launch {
            connection?.incomingPackets?.collect { packet ->
                when (packet.type) {
                    PacketType.TYPING_START -> {
                        _isPartnerTyping.value = true
                    }
                    PacketType.TYPING_STOP -> {
                        _isPartnerTyping.value = false
                    }
                    PacketType.CHAT -> {
                        _isPartnerTyping.value = false
                        // Automatically send back ACK
                        sendAck(packet.id)
                        _receivedPackets.emit(packet)
                    }
                    PacketType.ACK, PacketType.CONNECT_REQUEST, PacketType.CONNECT_RESPONSE -> {
                        _receivedPackets.emit(packet)
                    }
                }
            }
        }
    }

    override fun sendChatMessage(id: String, text: String): Boolean {
        val currentState = _connectionState.value
        if (currentState !is ConnectionState.Connected || connection == null) {
            Log.e(TAG, "Cannot send message: Not connected")
            return false
        }

        val packet = BluetoothPacket(
            type = PacketType.CHAT,
            id = id,
            senderAddress = bluetoothManager.getMyDeviceAddress(),
            senderName = bluetoothManager.getMyDeviceName(),
            text = text,
            timestamp = System.currentTimeMillis()
        )

        return connection?.sendPacket(packet) ?: false
    }

    override fun sendPacket(packet: BluetoothPacket): Boolean {
        return connection?.sendPacket(packet) ?: false
    }

    private fun sendAck(ackMessageId: String) {
        val packet = BluetoothPacket(
            type = PacketType.ACK,
            senderAddress = bluetoothManager.getMyDeviceAddress(),
            senderName = bluetoothManager.getMyDeviceName(),
            ackMessageId = ackMessageId
        )
        connection?.sendPacket(packet)
    }

    override fun sendTypingStatus(isTyping: Boolean) {
        val currentState = _connectionState.value
        if (currentState !is ConnectionState.Connected || connection == null) return

        val packet = BluetoothPacket(
            type = if (isTyping) PacketType.TYPING_START else PacketType.TYPING_STOP,
            senderAddress = bluetoothManager.getMyDeviceAddress(),
            senderName = bluetoothManager.getMyDeviceName()
        )
        connection?.sendPacket(packet)
    }

    override fun isConnected(): Boolean {
        return _connectionState.value is ConnectionState.Connected
    }

    override fun reconnect() {
        val lastDevice = lastConnectedDevice
        if (lastDevice != null) {
            connectToDevice(lastDevice)
        } else {
            startHost()
        }
    }

    private fun triggerAutoReconnect() {
        if (!shouldAutoReconnect || lastConnectedDevice == null) return

        serviceScope.launch {
            Log.d(TAG, "Attempting auto-reconnect in 3 seconds...")
            delay(3000)
            if (_connectionState.value is ConnectionState.Disconnected && shouldAutoReconnect) {
                lastConnectedDevice?.let { device ->
                    Log.d(TAG, "Auto reconnecting to ${device.address}")
                    connectToDevice(device)
                }
            }
        }
    }

    override fun disconnect() {
        shouldAutoReconnect = false
        stopAll()
        _connectionState.value = ConnectionState.Disconnected
        _isPartnerTyping.value = false
    }

    private fun stopAll() {
        try {
            connection?.close()
            connection = null

            server?.stop()
            server = null

            client?.stop()
            client = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping services: ${e.message}")
        }
    }

    override fun onDestroy() {
        shouldAutoReconnect = false
        stopAll()
        bluetoothManager.unregisterReceiver()
    }
}
