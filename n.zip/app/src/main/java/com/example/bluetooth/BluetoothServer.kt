package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothServerSocket
import android.bluetooth.BluetoothSocket
import android.util.Log
import java.io.IOException
import java.util.UUID

class BluetoothServer(
    private val adapter: BluetoothAdapter,
    private val serviceName: String = "BluetoothChatService",
    private val uuid: UUID
) {
    private val TAG = "BluetoothServer"
    private var serverSocket: BluetoothServerSocket? = null
    @Volatile
    private var isListening = false

    @SuppressLint("MissingPermission")
    fun startListening(onConnected: (BluetoothSocket) -> Unit, onError: (String) -> Unit) {
        Thread {
            try {
                serverSocket = adapter.listenUsingRfcommWithServiceRecord(serviceName, uuid)
                isListening = true
                Log.d(TAG, "Server listening started...")

                while (isListening) {
                    val socket: BluetoothSocket? = try {
                        serverSocket?.accept()
                    } catch (e: IOException) {
                        if (isListening) {
                            Log.e(TAG, "Server accept failed: ${e.message}")
                            onError(e.localizedMessage ?: "فشل قبول الاتصال")
                        }
                        null
                    }

                    socket?.let {
                        isListening = false
                        serverSocket?.close()
                        onConnected(it)
                        return@Thread
                    }
                }
            } catch (e: SecurityException) {
                Log.e(TAG, "Missing Bluetooth permission: ${e.message}")
                onError("خطأ في الصلاحيات: ${e.message}")
            } catch (e: Exception) {
                Log.e(TAG, "Server exception: ${e.message}")
                onError("خطأ في الخادم: ${e.message}")
            }
        }.start()
    }

    fun stop() {
        isListening = false
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing server socket: ${e.message}")
        }
    }
}
