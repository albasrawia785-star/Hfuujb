package com.example.bluetooth

import android.bluetooth.BluetoothSocket
import android.util.Log
import com.example.model.BluetoothPacket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream

class BluetoothConnection(
    private val socket: BluetoothSocket,
    private val onConnectionClosed: () -> Unit
) {
    private val TAG = "BluetoothConnection"

    private val _incomingPackets = MutableSharedFlow<BluetoothPacket>(extraBufferCapacity = 128)
    val incomingPackets: SharedFlow<BluetoothPacket> = _incomingPackets.asSharedFlow()

    private val connectionScope = CoroutineScope(Dispatchers.IO + Job())
    @Volatile
    private var isConnected = true

    private var outputStream: OutputStream? = null

    init {
        startReceiveThread()
    }

    private fun startReceiveThread() {
        connectionScope.launch {
            try {
                val inputStream = socket.inputStream
                outputStream = socket.outputStream
                val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

                while (isActive && isConnected) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) {
                        val packet = BluetoothPacket.fromJsonString(line)
                        if (packet != null) {
                            _incomingPackets.emit(packet)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Receive thread exception: ${e.message}")
            } finally {
                closeInternal()
            }
        }
    }

    fun sendPacket(packet: BluetoothPacket): Boolean {
        if (!isConnected) return false
        return try {
            val jsonLine = packet.toJsonString() + "\n"
            synchronized(this) {
                outputStream?.write(jsonLine.toByteArray(Charsets.UTF_8))
                outputStream?.flush()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send packet: ${e.message}")
            closeInternal()
            false
        }
    }

    private fun closeInternal() {
        if (isConnected) {
            isConnected = false
            try {
                socket.close()
            } catch (e: Exception) {
                Log.e(TAG, "Error closing socket: ${e.message}")
            }
            onConnectionClosed()
        }
    }

    fun close() {
        closeInternal()
    }
}
