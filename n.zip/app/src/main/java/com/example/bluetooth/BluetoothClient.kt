package com.example.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.util.Log
import java.io.IOException
import java.util.UUID

class BluetoothClient(
    private val adapter: BluetoothAdapter,
    private val uuid: UUID
) {
    private val TAG = "BluetoothClient"
    private var clientSocket: BluetoothSocket? = null

    @SuppressLint("MissingPermission")
    fun connectToDevice(
        device: BluetoothDevice,
        onConnected: (BluetoothSocket) -> Unit,
        onError: (String) -> Unit
    ) {
        Thread {
            try {
                if (adapter.isDiscovering) {
                    adapter.cancelDiscovery()
                }
                clientSocket = device.createRfcommSocketToServiceRecord(uuid)
                clientSocket?.connect()
                clientSocket?.let { socket ->
                    onConnected(socket)
                }
            } catch (e: IOException) {
                Log.e(TAG, "Failed to connect to device: ${e.message}")
                try {
                    clientSocket?.close()
                } catch (closeException: Exception) {
                    Log.e(TAG, "Could not close client socket", closeException)
                }
                onError(e.localizedMessage ?: "فشل الاتصال بالجهاز")
            } catch (e: SecurityException) {
                Log.e(TAG, "SecurityException connecting to device: ${e.message}")
                onError("خطأ صلاحيات البلوتوث: ${e.message}")
            }
        }.start()
    }

    fun stop() {
        try {
            clientSocket?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing client socket: ${e.message}")
        }
    }
}
