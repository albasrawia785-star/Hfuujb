package com.example.connection

import android.content.Context
import com.example.bluetooth.BluetoothService
import com.example.model.BluetoothDeviceDomain
import com.example.model.BluetoothPacket
import com.example.model.ConnectionState
import com.example.model.ConnectionType
import com.example.wifi.WifiService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

import com.example.model.ConnectionRequest
import com.example.model.OutgoingRequestStatus
import com.example.model.PacketType

class ConnectionManager(
    private val context: Context,
    val bluetoothService: BluetoothService,
    val wifiService: WifiService
) {
    private val _connectionType = MutableStateFlow(ConnectionType.BLUETOOTH)
    val connectionType: StateFlow<ConnectionType> = _connectionType.asStateFlow()

    private val managerScope = CoroutineScope(Dispatchers.IO + Job())

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _receivedPackets = MutableSharedFlow<BluetoothPacket>(extraBufferCapacity = 128)
    val receivedPackets: SharedFlow<BluetoothPacket> = _receivedPackets.asSharedFlow()

    private val _isPartnerTyping = MutableStateFlow(false)
    val isPartnerTyping: StateFlow<Boolean> = _isPartnerTyping.asStateFlow()

    private val _incomingRequest = MutableStateFlow<ConnectionRequest?>(null)
    val incomingRequest: StateFlow<ConnectionRequest?> = _incomingRequest.asStateFlow()

    private val _outgoingRequestStatus = MutableStateFlow(OutgoingRequestStatus.NONE)
    val outgoingRequestStatus: StateFlow<OutgoingRequestStatus> = _outgoingRequestStatus.asStateFlow()

    init {
        // Collect Bluetooth packets
        managerScope.launch {
            bluetoothService.receivedPackets.collect { packet ->
                handleIncomingPacket(packet, ConnectionType.BLUETOOTH)
            }
        }

        // Collect Wi-Fi packets
        managerScope.launch {
            wifiService.receivedPackets.collect { packet ->
                handleIncomingPacket(packet, ConnectionType.WIFI_LAN)
            }
        }

        // Collect Bluetooth State
        managerScope.launch {
            bluetoothService.connectionState.collect { state ->
                if (_connectionType.value == ConnectionType.BLUETOOTH) {
                    _connectionState.value = state
                }
            }
        }

        // Collect Wi-Fi State
        managerScope.launch {
            wifiService.connectionState.collect { state ->
                if (_connectionType.value == ConnectionType.WIFI_LAN) {
                    _connectionState.value = state
                }
            }
        }

        // Collect Bluetooth Typing
        managerScope.launch {
            bluetoothService.isPartnerTyping.collect { isTyping ->
                if (_connectionType.value == ConnectionType.BLUETOOTH) {
                    _isPartnerTyping.value = isTyping
                }
            }
        }

        // Collect Wi-Fi Typing
        managerScope.launch {
            wifiService.isPartnerTyping.collect { isTyping ->
                if (_connectionType.value == ConnectionType.WIFI_LAN) {
                    _isPartnerTyping.value = isTyping
                }
            }
        }
    }

    private suspend fun handleIncomingPacket(packet: BluetoothPacket, type: ConnectionType) {
        if (_connectionType.value != type) return

        when (packet.type) {
            PacketType.CONNECT_REQUEST -> {
                _incomingRequest.value = ConnectionRequest(
                    senderName = packet.senderName,
                    senderAddress = packet.senderAddress,
                    connectionType = type
                )
            }
            PacketType.CONNECT_RESPONSE -> {
                if (packet.text == "ACCEPTED") {
                    _outgoingRequestStatus.value = OutgoingRequestStatus.ACCEPTED
                } else if (packet.text == "DECLINED") {
                    _outgoingRequestStatus.value = OutgoingRequestStatus.DECLINED
                    disconnect()
                }
            }
            else -> {
                _receivedPackets.emit(packet)
            }
        }
    }

    fun sendConnectionRequest(addressOrIp: String, name: String? = null) {
        managerScope.launch {
            _outgoingRequestStatus.value = OutgoingRequestStatus.WAITING
            connectToDevice(addressOrIp, name)

            // Wait until connected to send CONNECT_REQUEST packet
            val startTime = System.currentTimeMillis()
            while (connectionState.value !is ConnectionState.Connected && System.currentTimeMillis() - startTime < 10000) {
                kotlinx.coroutines.delay(200)
            }

            if (connectionState.value is ConnectionState.Connected) {
                val packet = BluetoothPacket(
                    type = PacketType.CONNECT_REQUEST,
                    senderAddress = getMyAddress(),
                    senderName = getMyName()
                )
                getActiveConnection().sendPacket(packet)
            } else {
                _outgoingRequestStatus.value = OutgoingRequestStatus.NONE
            }
        }
    }

    fun acceptRequest(request: ConnectionRequest) {
        managerScope.launch {
            val packet = BluetoothPacket(
                type = PacketType.CONNECT_RESPONSE,
                senderAddress = getMyAddress(),
                senderName = getMyName(),
                text = "ACCEPTED"
            )
            getActiveConnection().sendPacket(packet)
            _incomingRequest.value = null
        }
    }

    fun declineRequest(request: ConnectionRequest) {
        managerScope.launch {
            val packet = BluetoothPacket(
                type = PacketType.CONNECT_RESPONSE,
                senderAddress = getMyAddress(),
                senderName = getMyName(),
                text = "DECLINED"
            )
            getActiveConnection().sendPacket(packet)
            _incomingRequest.value = null
            disconnect()
        }
    }

    fun resetOutgoingRequestStatus() {
        _outgoingRequestStatus.value = OutgoingRequestStatus.NONE
    }

    fun setConnectionType(type: ConnectionType) {
        if (_connectionType.value != type) {
            getActiveConnection().disconnect()
            _connectionType.value = type
            _connectionState.value = ConnectionState.Disconnected
            _isPartnerTyping.value = false
        }
    }

    fun getActiveConnection(): ChatConnection {
        return when (_connectionType.value) {
            ConnectionType.BLUETOOTH -> bluetoothService
            ConnectionType.WIFI_LAN -> wifiService
        }
    }

    fun startHost() {
        getActiveConnection().startHost()
    }

    fun connectToDevice(addressOrIp: String, name: String? = null) {
        getActiveConnection().connectToDevice(addressOrIp, name)
    }

    fun connectToBluetoothDevice(deviceDomain: BluetoothDeviceDomain) {
        setConnectionType(ConnectionType.BLUETOOTH)
        bluetoothService.connectToDevice(deviceDomain)
    }

    fun sendChatMessage(id: String, text: String): Boolean {
        return getActiveConnection().sendChatMessage(id, text)
    }

    fun sendTypingStatus(isTyping: Boolean) {
        getActiveConnection().sendTypingStatus(isTyping)
    }

    fun reconnect() {
        getActiveConnection().reconnect()
    }

    fun disconnect() {
        getActiveConnection().disconnect()
    }

    fun getMyAddress(): String {
        return when (_connectionType.value) {
            ConnectionType.BLUETOOTH -> bluetoothService.bluetoothManager.getMyDeviceAddress()
            ConnectionType.WIFI_LAN -> com.example.utils.WifiUtils.getLocalIpAddress()
        }
    }

    fun getMyName(): String {
        return when (_connectionType.value) {
            ConnectionType.BLUETOOTH -> bluetoothService.bluetoothManager.getMyDeviceName()
            ConnectionType.WIFI_LAN -> com.example.utils.WifiUtils.getDeviceName()
        }
    }

    fun onDestroy() {
        bluetoothService.onDestroy()
        wifiService.onDestroy()
    }
}
