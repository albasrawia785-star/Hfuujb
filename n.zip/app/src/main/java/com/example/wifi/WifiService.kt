package com.example.wifi

import android.content.Context
import android.util.Log
import com.example.connection.ChatConnection
import com.example.model.BluetoothDeviceDomain
import com.example.model.BluetoothPacket
import com.example.model.ConnectionState
import com.example.model.ConnectionType
import com.example.model.PacketType
import com.example.model.WifiHostDomain
import com.example.utils.WifiUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket

class WifiService(
    private val context: Context
) : ChatConnection {

    private val TAG = "WifiService"
    val TCP_PORT = 8888
    val UDP_PORT = 8889

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    override val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _receivedPackets = MutableSharedFlow<BluetoothPacket>(extraBufferCapacity = 128)
    override val receivedPackets: SharedFlow<BluetoothPacket> = _receivedPackets.asSharedFlow()

    private val _isPartnerTyping = MutableStateFlow(false)
    override val isPartnerTyping: StateFlow<Boolean> = _isPartnerTyping.asStateFlow()

    private val _discoveredHosts = MutableStateFlow<List<WifiHostDomain>>(emptyList())
    val discoveredHosts: StateFlow<List<WifiHostDomain>> = _discoveredHosts.asStateFlow()

    private val _isDiscovering = MutableStateFlow(false)
    val isDiscovering: StateFlow<Boolean> = _isDiscovering.asStateFlow()

    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null
    private var outputStream: OutputStream? = null

    private var udpHostSocket: DatagramSocket? = null
    private var udpDiscoverySocket: DatagramSocket? = null

    private var lastConnectedIp: String? = null
    private var lastConnectedName: String? = null
    private var shouldAutoReconnect = false

    init {
        startBackgroundService()
    }

    fun startBackgroundService() {
        serviceScope.launch(Dispatchers.IO) {
            startUdpHostResponder()
            startTcpListener()
        }
    }

    private fun startTcpListener() {
        if (serverSocket != null && !serverSocket!!.isClosed) return
        try {
            serverSocket = ServerSocket(TCP_PORT)
            Log.d(TAG, "Default TCP Server listener started on port $TCP_PORT")
            while (serviceScope.isActive && clientSocket == null) {
                val socket = serverSocket?.accept() ?: break
                if (_connectionState.value !is ConnectionState.Connected) {
                    handleSuccessfulConnection(socket, isHost = true)
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "TCP listener ended/closed: ${e.message}")
        }
    }

    override fun startHost() {
        if (_connectionState.value is ConnectionState.Connected) return
        _connectionState.value = ConnectionState.Listening
        startBackgroundService()
    }

    private fun startUdpHostResponder() {
        if (udpHostSocket != null && !udpHostSocket!!.isClosed) return
        try {
            udpHostSocket = DatagramSocket(UDP_PORT)
            val buffer = ByteArray(1024)

            while (serviceScope.isActive && _connectionState.value !is ConnectionState.Connected) {
                val packet = DatagramPacket(buffer, buffer.size)
                udpHostSocket?.receive(packet)

                val message = String(packet.data, 0, packet.length).trim()
                if (message.startsWith("DISCOVER_WIFI_CHAT")) {
                    val responseMsg = "WIFI_CHAT_OFFER|${WifiUtils.getDeviceName()}|${WifiUtils.getLocalIpAddress()}|$TCP_PORT"
                    val responseData = responseMsg.toByteArray(Charsets.UTF_8)
                    val responsePacket = DatagramPacket(
                        responseData,
                        responseData.size,
                        packet.address,
                        packet.port
                    )
                    udpHostSocket?.send(responsePacket)
                    Log.d(TAG, "Responded to discovery request from ${packet.address.hostAddress}")
                }
            }
        } catch (e: Exception) {
            Log.d(TAG, "UDP Host responder closed: ${e.message}")
        }
    }

    override fun connectToDevice(addressOrIp: String, name: String?) {
        stopAll()
        val targetIp = addressOrIp.trim()
        val targetName = name ?: "خادم Wi-Fi ($targetIp)"

        _connectionState.value = ConnectionState.Connecting(targetName)
        lastConnectedIp = targetIp
        lastConnectedName = targetName
        shouldAutoReconnect = true

        serviceScope.launch(Dispatchers.IO) {
            try {
                val socket = Socket(targetIp, TCP_PORT)
                handleSuccessfulConnection(socket, isHost = false, overrideName = targetName)
            } catch (e: Exception) {
                Log.e(TAG, "Client socket connect error: ${e.message}")
                _connectionState.value = ConnectionState.Error("فشل الاتصال بالـ IP ($targetIp): ${e.localizedMessage}")
                triggerAutoReconnect()
            }
        }
    }

    fun startAutoDiscovery() {
        _isDiscovering.value = true
        _discoveredHosts.value = emptyList()

        serviceScope.launch(Dispatchers.IO) {
            try {
                udpDiscoverySocket?.close()
                udpDiscoverySocket = DatagramSocket()
                udpDiscoverySocket?.broadcast = true

                val requestData = "DISCOVER_WIFI_CHAT|${WifiUtils.getDeviceName()}".toByteArray(Charsets.UTF_8)

                // 1. Send UDP Broadcast to Subnet & Global Broadcast
                try {
                    val broadcastAddr = InetAddress.getByName(WifiUtils.getBroadcastAddress())
                    val globalBroadcastAddr = InetAddress.getByName("255.255.255.255")
                    val packet1 = DatagramPacket(requestData, requestData.size, broadcastAddr, UDP_PORT)
                    val packet2 = DatagramPacket(requestData, requestData.size, globalBroadcastAddr, UDP_PORT)

                    repeat(2) {
                        udpDiscoverySocket?.send(packet1)
                        udpDiscoverySocket?.send(packet2)
                        delay(200)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Broadcast send error: ${e.message}")
                }

                // 2. Subnet IP Unicast Probe (Fast Parallel Sweep)
                val localIp = WifiUtils.getLocalIpAddress()
                if (localIp != "127.0.0.1" && localIp.contains(".")) {
                    val prefix = localIp.substringBeforeLast(".") + "."
                    launch(Dispatchers.IO) {
                        (1..254).map { i ->
                            async {
                                val targetIp = "$prefix$i"
                                if (targetIp != localIp) {
                                    try {
                                        val inet = InetAddress.getByName(targetIp)
                                        val unicastPacket = DatagramPacket(requestData, requestData.size, inet, UDP_PORT)
                                        udpDiscoverySocket?.send(unicastPacket)
                                    } catch (ignored: Exception) {}
                                }
                            }
                        }.awaitAll()
                    }
                }

                val buffer = ByteArray(1024)
                val startTime = System.currentTimeMillis()

                udpDiscoverySocket?.soTimeout = 3000

                while (isActive && (System.currentTimeMillis() - startTime) < 5000) {
                    try {
                        val recvPacket = DatagramPacket(buffer, buffer.size)
                        udpDiscoverySocket?.receive(recvPacket)

                        val response = String(recvPacket.data, 0, recvPacket.length).trim()
                        if (response.startsWith("WIFI_CHAT_OFFER")) {
                            val parts = response.split("|")
                            if (parts.size >= 4) {
                                val hostName = parts[1]
                                val hostIp = parts[2]
                                val hostPort = parts[3].toIntOrNull() ?: TCP_PORT

                                val newHost = WifiHostDomain(
                                    name = hostName,
                                    ipAddress = hostIp,
                                    port = hostPort,
                                    rssi = -45 // Strong Wi-Fi LAN signal
                                )

                                val currentList = _discoveredHosts.value.toMutableList()
                                if (currentList.none { it.ipAddress == hostIp }) {
                                    currentList.add(newHost)
                                    _discoveredHosts.value = currentList
                                }
                            }
                        }
                    } catch (e: Exception) {
                        // Timeout or socket closed
                        break
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "UDP Discovery error: ${e.message}")
            } finally {
                _isDiscovering.value = false
            }
        }
    }

    private fun handleSuccessfulConnection(
        socket: Socket,
        isHost: Boolean,
        overrideName: String? = null
    ) {
        clientSocket = socket
        val remoteIp = socket.inetAddress.hostAddress ?: "127.0.0.1"
        val remoteName = overrideName ?: "جهاز Wi-Fi ($remoteIp)"

        val deviceDomain = BluetoothDeviceDomain(
            name = remoteName,
            address = remoteIp
        )

        lastConnectedIp = remoteIp
        lastConnectedName = remoteName
        shouldAutoReconnect = true

        _connectionState.value = ConnectionState.Connected(
            device = deviceDomain,
            connectionType = ConnectionType.WIFI_LAN,
            ipAddress = remoteIp,
            port = TCP_PORT
        )

        // Close UDP server responder once connected
        udpHostSocket?.close()
        udpHostSocket = null

        // Receive loop
        serviceScope.launch(Dispatchers.IO) {
            try {
                val inputStream = socket.getInputStream()
                outputStream = socket.getOutputStream()
                val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))

                while (isActive && socket.isConnected && !socket.isClosed) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) {
                        val pkt = BluetoothPacket.fromJsonString(line)
                        if (pkt != null) {
                            when (pkt.type) {
                                PacketType.TYPING_START -> _isPartnerTyping.value = true
                                PacketType.TYPING_STOP -> _isPartnerTyping.value = false
                                PacketType.CHAT -> {
                                    _isPartnerTyping.value = false
                                    sendAck(pkt.id)
                                    _receivedPackets.emit(pkt)
                                }
                                PacketType.ACK, PacketType.CONNECT_REQUEST, PacketType.CONNECT_RESPONSE -> {
                                    _receivedPackets.emit(pkt)
                                }
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Wi-Fi TCP read error: ${e.message}")
            } finally {
                Log.d(TAG, "Wi-Fi Connection lost/closed")
                _connectionState.value = ConnectionState.Disconnected
                _isPartnerTyping.value = false
                triggerAutoReconnect()
            }
        }
    }

    override fun sendChatMessage(id: String, text: String): Boolean {
        if (!isConnected()) return false
        val packet = BluetoothPacket(
            type = PacketType.CHAT,
            id = id,
            senderAddress = WifiUtils.getLocalIpAddress(),
            senderName = WifiUtils.getDeviceName(),
            text = text,
            timestamp = System.currentTimeMillis()
        )
        return sendPacketInternal(packet)
    }

    override fun sendPacket(packet: BluetoothPacket): Boolean {
        return sendPacketInternal(packet)
    }

    private fun sendAck(ackMessageId: String) {
        val packet = BluetoothPacket(
            type = PacketType.ACK,
            senderAddress = WifiUtils.getLocalIpAddress(),
            senderName = WifiUtils.getDeviceName(),
            ackMessageId = ackMessageId
        )
        sendPacketInternal(packet)
    }

    override fun sendTypingStatus(isTyping: Boolean) {
        if (!isConnected()) return
        val packet = BluetoothPacket(
            type = if (isTyping) PacketType.TYPING_START else PacketType.TYPING_STOP,
            senderAddress = WifiUtils.getLocalIpAddress(),
            senderName = WifiUtils.getDeviceName()
        )
        sendPacketInternal(packet)
    }

    private fun sendPacketInternal(packet: BluetoothPacket): Boolean {
        return try {
            val jsonLine = packet.toJsonString() + "\n"
            synchronized(this) {
                outputStream?.write(jsonLine.toByteArray(Charsets.UTF_8))
                outputStream?.flush()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to send packet over Wi-Fi: ${e.message}")
            disconnect()
            false
        }
    }

    override fun isConnected(): Boolean {
        return _connectionState.value is ConnectionState.Connected && clientSocket?.isConnected == true
    }

    override fun reconnect() {
        val lastIp = lastConnectedIp
        if (lastIp != null) {
            connectToDevice(lastIp, lastConnectedName)
        } else {
            startHost()
        }
    }

    private fun triggerAutoReconnect() {
        if (!shouldAutoReconnect || lastConnectedIp == null) return

        serviceScope.launch {
            Log.d(TAG, "Attempting Wi-Fi auto-reconnect in 3 seconds...")
            delay(3000)
            if (_connectionState.value is ConnectionState.Disconnected && shouldAutoReconnect) {
                lastConnectedIp?.let { ip ->
                    Log.d(TAG, "Auto reconnecting to Wi-Fi host $ip...")
                    connectToDevice(ip, lastConnectedName)
                }
            }
        }
    }

    override fun disconnect() {
        shouldAutoReconnect = false
        stopAll()
        _connectionState.value = ConnectionState.Disconnected
        _isPartnerTyping.value = false
    }

    private fun stopAll() {
        try {
            clientSocket?.close()
            clientSocket = null

            serverSocket?.close()
            serverSocket = null

            udpHostSocket?.close()
            udpHostSocket = null

            udpDiscoverySocket?.close()
            udpDiscoverySocket = null

            outputStream = null
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping Wi-Fi services: ${e.message}")
        }
    }

    override fun onDestroy() {
        disconnect()
    }
}
