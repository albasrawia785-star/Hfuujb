package com.example.model

enum class ConnectionType {
    BLUETOOTH,
    WIFI_LAN
}
