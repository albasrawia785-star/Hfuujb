package com.example.model

data class ConnectionRequest(
    val senderName: String,
    val senderAddress: String,
    val connectionType: ConnectionType
)

enum class OutgoingRequestStatus {
    NONE,
    WAITING,
    ACCEPTED,
    DECLINED
}
