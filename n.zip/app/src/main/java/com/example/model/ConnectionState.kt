package com.example.model

sealed interface ConnectionState {
    object Disconnected : ConnectionState
    object Listening : ConnectionState
    data class Connecting(val deviceName: String?) : ConnectionState
    data class Connected(
        val device: BluetoothDeviceDomain,
        val connectionType: ConnectionType = ConnectionType.BLUETOOTH,
        val ipAddress: String? = null,
        val port: Int? = null
    ) : ConnectionState
    data class Error(val message: String) : ConnectionState
}
