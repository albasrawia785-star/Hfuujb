package com.example.model

data class WifiHostDomain(
    val name: String,
    val ipAddress: String,
    val port: Int = 8888,
    val rssi: Int = -50,
    val isConnected: Boolean = false,
    val lastSeenTimestamp: Long = System.currentTimeMillis()
)
