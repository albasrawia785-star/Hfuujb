package com.example.model

import org.json.JSONObject
import java.util.UUID

enum class PacketType {
    CHAT,
    ACK,
    TYPING_START,
    TYPING_STOP,
    CONNECT_REQUEST,
    CONNECT_RESPONSE
}

data class BluetoothPacket(
    val type: PacketType,
    val id: String = UUID.randomUUID().toString(),
    val senderAddress: String,
    val senderName: String,
    val text: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val ackMessageId: String = ""
) {
    fun toJsonString(): String {
        return JSONObject().apply {
            put("type", type.name)
            put("id", id)
            put("senderAddress", senderAddress)
            put("senderName", senderName)
            put("text", text)
            put("timestamp", timestamp)
            put("ackMessageId", ackMessageId)
        }.toString()
    }

    companion object {
        fun fromJsonString(jsonString: String): BluetoothPacket? {
            return try {
                val json = JSONObject(jsonString)
                val typeName = json.optString("type", PacketType.CHAT.name)
                val packetType = try { PacketType.valueOf(typeName) } catch (e: Exception) { PacketType.CHAT }
                BluetoothPacket(
                    type = packetType,
                    id = json.optString("id", UUID.randomUUID().toString()),
                    senderAddress = json.optString("senderAddress", ""),
                    senderName = json.optString("senderName", "جهاز مجهول"),
                    text = json.optString("text", ""),
                    timestamp = json.optLong("timestamp", System.currentTimeMillis()),
                    ackMessageId = json.optString("ackMessageId", "")
                )
            } catch (e: Exception) {
                null
            }
        }
    }
}
