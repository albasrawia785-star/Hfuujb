package com.example.model

data class BluetoothDeviceDomain(
    val name: String?,
    val address: String,
    val rssi: Int = -60,
    val isConnected: Boolean = false
)
