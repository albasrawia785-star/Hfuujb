package com.example.model

data class ConversationSummary(
    val partnerAddress: String,
    val partnerName: String,
    val lastMessageText: String,
    val lastMessageTimestamp: Long,
    val unreadCount: Int
)
