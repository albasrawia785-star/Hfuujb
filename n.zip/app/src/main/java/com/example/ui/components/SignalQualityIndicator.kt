package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class SignalLevel(val label: String, val activeBars: Int, val color: Color) {
    EXCELLENT("ممتازة", 4, Color(0xFF2E7D32)), // Dark Green
    GOOD("قوية", 3, Color(0xFF1976D2)),      // Blue
    FAIR("متوسطة", 2, Color(0xFFF57C00)),     // Orange
    WEAK("ضعيفة", 1, Color(0xFFD32F2F))      // Red
}

fun getSignalLevelFromRssi(rssi: Int): SignalLevel {
    return when {
        rssi >= -60 -> SignalLevel.EXCELLENT
        rssi >= -72 -> SignalLevel.GOOD
        rssi >= -85 -> SignalLevel.FAIR
        else -> SignalLevel.WEAK
    }
}

@Composable
fun SignalBarsGraphic(
    rssi: Int,
    modifier: Modifier = Modifier,
    barWidth: Dp = 4.dp,
    maxBarHeight: Dp = 18.dp,
    spacing: Dp = 3.dp
) {
    val level = getSignalLevelFromRssi(rssi)
    val activeBars = level.activeBars
    val barColor = level.color
    val inactiveColor = barColor.copy(alpha = 0.25f)

    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(spacing),
        verticalAlignment = Alignment.Bottom
    ) {
        val totalBars = 4
        for (i in 1..totalBars) {
            val fraction = i.toFloat() / totalBars.toFloat()
            val barHeight = maxBarHeight * fraction
            val isFilled = i <= activeBars

            Box(
                modifier = Modifier
                    .width(barWidth)
                    .height(barHeight)
                    .background(
                        color = if (isFilled) barColor else inactiveColor,
                        shape = RoundedCornerShape(2.dp)
                    )
            )
        }
    }
}

@Composable
fun SignalQualityIndicator(
    rssi: Int,
    modifier: Modifier = Modifier,
    showLabel: Boolean = true
) {
    val level = getSignalLevelFromRssi(rssi)

    Row(
        modifier = modifier
            .background(
                color = level.color.copy(alpha = 0.1f),
                shape = RoundedCornerShape(12.dp)
            )
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SignalBarsGraphic(rssi = rssi)

        if (showLabel) {
            Spacer(modifier = Modifier.width(6.dp))
            Column(horizontalAlignment = Alignment.Start) {
                Text(
                    text = level.label,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = level.color
                )
                Text(
                    text = "$rssi dBm",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )
            }
        }
    }
}
